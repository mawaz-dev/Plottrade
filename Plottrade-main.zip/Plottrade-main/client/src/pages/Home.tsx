import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import SwiperCore from "swiper";
import "swiper/css/bundle";
import Listing, { type ListingItem } from "../components/Listing";

export default function Home(): React.JSX.Element {
  const [offerListings, setOfferListings] = useState<ListingItem[]>([]);
  const [saleListings, setSaleListings] = useState<ListingItem[]>([]);
  const [rentListings, setRentListings] = useState<ListingItem[]>([]);
  SwiperCore.use([Navigation]);

  useEffect(() => {
    const fetchOfferListings = async () => {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_URL}/listings/?offer=true&limit=4`,
        );
        const data = await res.json();
        setOfferListings(data);
        fetchRentListings();
      } catch (error) {
        console.log(error);
      }
    };
    const fetchRentListings = async () => {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_URL}/listings/?type=rent&limit=4`,
        );
        const data = await res.json();
        setRentListings(data);
        fetchSaleListings();
      } catch (error) {
        console.log(error);
      }
    };

    const fetchSaleListings = async () => {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_API_URL}/listings/?type=sale&limit=4`,
        );
        const data = await res.json();
        setSaleListings(data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchOfferListings();
  }, []);
  return (
    <div>
      {/* top */}
      <div className="flex flex-col lg:flex-row items-center justify-between p-10 px-3 max-w-6xl mx-auto">
        {/* Left Side: Content */}
        <div className="flex flex-col gap-6 flex-1">
          <h1 className="text-slate-700 font-bold text-3xl lg:text-6xl">
            Step into your future
            <span className="text-blue-500"> Door</span>
            <br />
            effortlessly
          </h1>
          <div className="text-gray-400 text-xs sm:text-sm">
            PlotTrade is the best place to find your next perfect place to live.
            <br />
            We have a wide range of properties for you to choose from.
          </div>

          <div className="flex items-start">
            <Link
              to="/search"
              className="inline-block px-6 py-3 bg-blue-500 text-white font-semibold rounded-full shadow-md hover:bg-blue-600 transition duration-200"
            >
              Let's get started...
            </Link>
          </div>
        </div>

        {/* Right Side: Image */}
        <div className="flex-1 flex justify-center items-center lg:justify-end w-full min-w-0 m-0 p-0">
          <img
            src="/hero.png"
            alt="Property graphic"
            className="w-full max-w-xs sm:max-w-md md:max-w-lg lg:max-w-xl h-auto max-h-[70vh] object-contain"
          />
        </div>
      </div>

      {/* swiper */}
      <Swiper navigation>
        {offerListings &&
          offerListings.length > 0 &&
          offerListings.map((listing) => (
            <SwiperSlide key={listing._id}>
              <div
                style={{
                  background: `url(${listing.imageUrls[0]}) center no-repeat`,
                  backgroundSize: "cover",
                }}
                className="h-[500px]"
              ></div>
            </SwiperSlide>
          ))}
      </Swiper>

      {/* listing results for offer, sale and rent */}

      <div className="max-w-6xl mx-auto p-3 flex flex-col gap-8 my-10">
        {offerListings && offerListings.length > 0 && (
          <div className="">
            <div className="my-3">
              <h2 className="text-2xl font-semibold text-slate-600">
                Recent offers
              </h2>
              <Link
                className="text-sm text-blue-800 hover:underline"
                to={"/search?offer=true"}
              >
                Show more offers
              </Link>
            </div>
            <div className="flex flex-wrap gap-4">
              {offerListings.map((listing) => (
                <Listing listing={listing} key={listing._id} />
              ))}
            </div>
          </div>
        )}
        {rentListings && rentListings.length > 0 && (
          <div className="">
            <div className="my-3">
              <h2 className="text-2xl font-semibold text-slate-600">
                Recent places for rent
              </h2>
              <Link
                className="text-sm text-blue-800 hover:underline"
                to={"/search?type=rent"}
              >
                Show more places for rent
              </Link>
            </div>
            <div className="flex flex-wrap gap-4">
              {rentListings.map((listing) => (
                <Listing listing={listing} key={listing._id} />
              ))}
            </div>
          </div>
        )}
        {saleListings && saleListings.length > 0 && (
          <div className="">
            <div className="my-3">
              <h2 className="text-2xl font-semibold text-slate-600">
                Recent places for sale
              </h2>
              <Link
                className="text-sm text-blue-800 hover:underline"
                to={"/search?type=sale"}
              >
                Show more places for sale
              </Link>
            </div>
            <div className="flex flex-wrap gap-4">
              {saleListings.map((listing) => (
                <Listing listing={listing} key={listing._id} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
